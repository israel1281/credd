<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class FwBPCableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
