<?php
return [
    'bvn_url' => env('VERIFY_ME_BVN_URL'),
    'pk_live' => env('VERIFY_ME_PK_LIVE'),
    'sk_live' => env('VERIFY_ME_SK_LIVE'),
    'sk_test' => env('VERIFY_ME_SK_TEST'),
];
