<?php
return [
    'url' => env('BLACKLIST_NG_URL'),
    'sk' => env('BLACKLIST_NG_SK'),
];
